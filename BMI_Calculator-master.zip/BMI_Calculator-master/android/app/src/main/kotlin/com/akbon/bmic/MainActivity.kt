package com.akbon.bmic

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
