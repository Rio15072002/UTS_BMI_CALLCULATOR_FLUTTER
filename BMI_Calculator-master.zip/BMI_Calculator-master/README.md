# <img src="https://raw.githubusercontent.com/AKB0N/BMI_Calculator/master/assets/icon/logo.png" width="50"/>   BMI Calculator app  <a href="https://play.google.com/store/apps/details?id=com.akbon.bmic"><img src="https://camo.githubusercontent.com/0970391e8ed2f4cf4b738e87494c203e0e13052a6b7fa0468588ff7984e9ea8a/68747470733a2f2f696d672e736869656c64732e696f2f62616467652f476f6f676c655f506c61792d3431343134313f7374796c653d666f722d7468652d6261646765266c6f676f3d676f6f676c652d706c6179266c6f676f436f6c6f723d7768697465?style=for-the-badge&logo=flutter&logoColor=white"></a>






BMI Calculator app project using Flutter

# Previews
<img src="https://raw.githubusercontent.com/AKB0N/BMI_Calculator/master/1.png"/> 

Version 1.0.0  :
* Created the app
* Publishing app on play store

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.


